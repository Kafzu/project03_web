
const http = require("http");
//const fs = require('./Router');
const path = require('path');
const router = require('./Router');

//const { Console } = require("console");
//const routeRequest = require("./Router");
//http://localhost:4200/Solution
//http://localhost:4200/Fabrication

const PORT = 4200;
const server = http.createServer((req, res) => {
    console.log(req.url);
    console.log(module);
    router.routeRequest(req, res);
 //router.routeRequest(req, res);
 //routeRequest(req, res);
});
server.listen(PORT, () => {
 console.log(`Serveur d'images écoutant sur le port ${PORT}`);
});

